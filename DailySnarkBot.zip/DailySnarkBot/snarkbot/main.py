
import praw
import os
from datetime import datetime
import schedule
import time
from flask import Flask
from pytz import timezone

app = Flask(__name__)

# --- Reddit API Setup ---
try:
    reddit = praw.Reddit(
        client_id=os.getenv('REDDIT_CLIENT_ID'),
        client_secret=os.getenv('REDDIT_CLIENT_SECRET'),
        username=os.getenv('REDDIT_USERNAME'),
        password=os.getenv('REDDIT_PASSWORD'),
        user_agent='DailySnarkBot by u/MinimumCorner1513'
    )
except Exception as e:
    print(f"Error connecting to Reddit: {e}")
    exit(1)

# --- Configuration ---
subreddit_name = "LillyTino_"

def create_daily_post():
    today = datetime.now(timezone('US/Eastern')).strftime("%B %d, %Y")
    post_title = f"Daily Snark – {today}"

    post_body = """
Welcome back to your regularly scheduled snark-fest! This is the place for all your eye-rolls, side-eyes, spicy takes, and popcorn-worthy moments.

Got a hot take that doesn't need its own post? Drop it here.  
Seen something absurd that made you cackle? We want it.  
Feel like dramatically whispering "girl…" at your screen? This thread was made for you.

Let the games begin.
"""

    try:
        # Check for existing post
        for submission in reddit.subreddit(subreddit_name).new(limit=5):
            if post_title in submission.title:
                print("Already posted today!")
                return
        
        # Create new post
        reddit.subreddit(subreddit_name).submit(title=post_title, selftext=post_body)
        print(f"Posted: {post_title}")
    except Exception as e:
        print(f"Error posting to Reddit: {e}")

# Schedule post for 9:30 AM EST daily
schedule.every().day.at("09:30").do(create_daily_post)

@app.route('/')
def home():
    return "Daily Snark Bot is running!"

if __name__ == '__main__':
    # Run scheduler in a separate thread
    import threading
    def run_schedule():
        while True:
            schedule.run_pending()
            time.sleep(60)
    
    scheduler_thread = threading.Thread(target=run_schedule)
    scheduler_thread.start()
    
    # Run Flask app
    app.run(host='0.0.0.0', port=8080)
